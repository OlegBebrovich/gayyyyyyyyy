import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import keras
import requests
import cv2 as cv
import numpy as np
from json import loads
from .imageConverter import process
from urllib.request import urlretrieve

filenameConvert = "autocaptcha/imagesProcessed"

config = loads(open("configs.json").read())

api = config["api"]


def convert(image):
    listImg = []
    img = cv.imread(image, 0)
    img = img - 255

    cutx = 9999
    cuty = 9999

    cutzx = 0
    cutzy = 0

    imgCopy = img.tolist()
    

    for i in range(len(imgCopy)):
        if 1 not in imgCopy[i]:
            continue
        if i < cuty:
            cuty = i
        if imgCopy[i].index(1) < cutx:
            cutx = imgCopy[i].index(1)
        if i > cutzy:
            cutzy = i
        val = [j for j in range(len(imgCopy[i])) if imgCopy[i][j]][-1]
        if val > cutzx:
            cutzx = val
            
    img = img[cuty:cutzy, cutx:cutzx]
    pth = 0
    plh = int(len(img[0])/6)
    imgs = []
    for i in range(6):
        imgs = img[0:-1, pth:pth+plh]
        imgs = cv.resize(imgs, (28, 28), interpolation=cv.INTER_AREA)
        listImg.append(imgs)
        pth += plh

    return listImg


def convert_image(image):
    process(image, f"{filenameConvert}/processed.png")
    values = convert(f"{filenameConvert}/processed.png")
    
    return np.array(values)


def resolve(image, hwid, key, security):
    val = convert_image(image)
    model = keras.models.load_model("autocaptcha/captcha.model")
    predictions = model.predict(val)
    
    data = {
        "key": key,
        "hwid": hwid,
        "security": security,
        "predictions": predictions.tolist()
    }
    val = requests.get(f"{api}/resolve", json=data)
    return val.json()


def captcha_solve(url: str, file: str, hwid, key, security):
    urlretrieve(url=url, filename=file)
    v1 = resolve(file, hwid, key, security)
    return v1
