import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import json
import random
import requests
import threading
import urllib3.exceptions

from hmac import new
from time import sleep
from hashlib import sha1
from colorama import Fore
from base64 import b64encode
from threading import Thread
from functions import Client, Mail
from pyfiglet import figlet_format
from autocaptcha.MainTrainer import captcha_solve

threads = 500
proxies = open("proxies.txt").read().split("\n")
nickname, password = json.loads(open("configs.json").read())["nickname"], json.loads(open("configs.json").read())["password"]


def gen(data: str):
    data = data.encode("utf-8")
    return b64encode(
                    bytes.fromhex("64") + 
                    new(
                        bytes.fromhex("5377AAA667B63370C531E6FC54A13037D8CB5F83B11DFA0A3F17BA372F9963AD3B359CFE07BC83BE32B3068DFD85E7F0AC1A6E38FBC7B8ED202FD2ACE63E0D9EC35359C9B2EF35C1C2357E78123AE9E2210252FF81285328823A"),
                        data, 
                        sha1
                        ).digest()
                    ).decode("utf-8")


def generate_mail():
    chars = "abcdefghijklnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    email = ""
    for _ in range(12): email += random.choice(chars)
    return f"{email}@wwjmp.com"


def main(hwid, key):
    try:
        client = Client()
        try:
            proxy = random.choice(proxies)
        except:
            return
        
        security = gen(data=str({
            "key": key,
            "hwid": hwid
        }))
        
        proxies.remove(proxy)
        
        client.set_proxy(proxy, hwid, key, security)
        deviceId = client.deviceId()
        client.set_device(deviceId)
        
        for _ in range(5):
            deviceId = client.deviceId()
            client.set_device(deviceId)
            email = generate_mail()
            mail_client = Mail(email)            
            response = client.request_verify_code(email=email, timeout=60)
            
            if not response:
                return
            if response["api:message"] == "OK":
                file = "autocaptcha/to_solve/" + str(random.randint(100, 10000000000)) + ".png"
                print(
                    f"{Fore.LIGHTMAGENTA_EX}> {Fore.RESET}прокси: {Fore.LIGHTMAGENTA_EX}{proxy}{Fore.RESET}.",
                    f"Отправили код подтверждения на {Fore.LIGHTMAGENTA_EX}{email}{Fore.RESET}.",
                    f"Капча {Fore.LIGHTMAGENTA_EX}{file}{Fore.RESET}"
                    )
            
                while True:
                    try:
                        sleep(3)
                        msg_id = mail_client.get_email_messages(hwid, key, security)
                        break
                    except:
                        pass
                    
                url = mail_client.get_email_link(msg_id, hwid, key, security)
                captcha = captcha_solve(url=url.replace('"', ''), file=file, hwid=hwid, key=key, security=security)
                captcha = str(captcha["val"])
                
                while True:
                    try:
                        response = client.register(nickname=nickname, email=email, password=password,
                                                   verificationCode=captcha, timeout=60)
                        
                        if response:
                            if "account" in response:
                                with open("accounts.txt", "a") as file:
                                    file.writelines(f"{email} {password} {client.device_id}\n")
                                    
                                    print(
                                        f"{Fore.LIGHTMAGENTA_EX}> {Fore.RESET}прокси: {Fore.LIGHTMAGENTA_EX}{proxy}{Fore.RESET}.",
                                        f"зарегистрировали {Fore.LIGHTMAGENTA_EX}{email}{Fore.RESET}.",
                                        f"Капча {Fore.LIGHTMAGENTA_EX}{captcha}{Fore.RESET}"
                                        )
                                break
                            else:
                                print(
                                f"{Fore.LIGHTMAGENTA_EX}> {Fore.RESET}прокси: {Fore.LIGHTMAGENTA_EX}{proxy}{Fore.RESET}.",
                                f"Не удалось зарегестрировать {Fore.LIGHTMAGENTA_EX}{email}{Fore.RESET}, из-за ошибки {Fore.LIGHTMAGENTA_EX}в АМИНО{Fore.RESET} (это {Fore.LIGHTMAGENTA_EX}не ошибка авторега{Fore.RESET}).",
                                f"Капча {Fore.LIGHTMAGENTA_EX}{file}{Fore.RESET}.")
                                try:
                                    code = response["api:statuscode"]
                                    
                                    if code == 110:
                                        return
                                    elif code == 219:
                                        client.set_device(client.deviceId())
                                        continue
                                    elif code == 270 or code == 291:
                                        return
                                    elif code == 3102:
                                        continue
                                    
                                except KeyError:
                                    return
                        else:
                            continue
                    except requests.exceptions.ProxyError:
                        print(
                            f"{Fore.LIGHTMAGENTA_EX}> {Fore.RESET}прокси: {Fore.LIGHTMAGENTA_EX}{proxy}{Fore.RESET}.",
                            f"Не удалось зарегестрировать {Fore.LIGHTMAGENTA_EX}{email}{Fore.RESET}, из-за ошибки {Fore.LIGHTMAGENTA_EX}прокси{Fore.RESET} (это {Fore.LIGHTMAGENTA_EX}не ошибка авторега{Fore.RESET}).",
                            f"Капча {Fore.LIGHTMAGENTA_EX}{file}{Fore.RESET}.")
                        continue
            else:
                return
    except requests.exceptions.ConnectionError:
        return
    except urllib3.exceptions.ProtocolError:
        return


def start(hwid, key):
    global proxies
    print(Fore.LIGHTMAGENTA_EX + "\n".join(figlet_format("AutoReg", font="smslant").rstrip().split("\n")[:3]))
    print(Fore.RESET + "\n".join(figlet_format("AutoReg", font="smslant").rstrip().split("\n")[3:]))
    print(Fore.LIGHTMAGENTA_EX + "> " + Fore.RESET + "made by " + Fore.LIGHTMAGENTA_EX + "RYUJIN" + Fore.RESET + "\n\nSecurity and autocaptcha by" + Fore.LIGHTMAGENTA_EX + " https://t.me/Verve_is_God")
    print(f"\n\n\n{Fore.LIGHTMAGENTA_EX}> {Fore.RESET}загружено {Fore.LIGHTMAGENTA_EX}{len(proxies)}{Fore.RESET} прокси.")
    while True:
        print(
        f"{Fore.LIGHTMAGENTA_EX}> {Fore.RESET}активно {Fore.LIGHTMAGENTA_EX}{threading.active_count()}{Fore.RESET} потоков.",
        f"осталось {Fore.LIGHTMAGENTA_EX}{len(proxies)}{Fore.RESET} непроверенных прокси."
        )
    
        if proxies:
            for _ in range(threads - threading.active_count()):
                Thread(target=main, args=(hwid, key,)).start()
        else:
            proxies = open("proxies.txt").read().split("\n")
            print(f"{Fore.LIGHTMAGENTA_EX}> {Fore.RESET}загружено {Fore.LIGHTMAGENTA_EX}{len(proxies)}{Fore.RESET} прокси.")
        
        sleep(12)
