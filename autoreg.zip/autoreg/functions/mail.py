import requests
from json import loads

config = loads(open("configs.json").read())

api = config["api"]


class Mail:
    def __init__(self, mail):
        self.mail = mail
        self.api = "http://www.1secmail.com/api/v1/"
        self.login, self.domain = self.mail.split("@")

    def get_email_messages(self, hwid, key, security):
        data = {
            "security": security,
            "hwid": hwid,
            "key": key,
            "login": self.login,
            "domain": self.domain
        }
        msg_id = requests.get(f"{api}/messages",
                              json=data).json()
        if msg_id["status"] == 0:
            return msg_id["msg_id"]
        elif msg_id["status"] == 1:
            exit("Ваш ключ забанен! Обратитесь к https://t.me/Verve_is_God, если считаете что это ошибка.")
        elif msg_id["status"] == 2:
            exit("Срок вашего ключа истёк! Обратитесь к https://t.me/Verve_is_God, если хотите продлить подписку.")
        elif msg_id["status"] == 3:
            exit("Данный ключ не существует! Обратитесь к https://t.me/Verve_is_God, если хотите купить ключ.")
        elif msg_id["status"] == 4:
            exit(f"Версия, которую вы используете ({version}) не действительна. Обратитесь к https://t.me/Verve_is_God за новой версией.")
        elif msg_id["status"] == 100:
            exit("Сервер обновляется. Приносим свои извинения! Попробуйте запустить скрипт через 5 минут, если ошибка снова повторится обратитесь к https://t.me/Verve_is_God")
        elif msg_id["status"] == 101:
            exit("Сервер изменил сигнатуру, обратитесь к https://t.me/Verve_is_God.")
        elif msg_id["status"] == 500:
            exit("Внутренняя ошибка сервера.")
        else:
            exit("Неизвестная ошибка, обратитесь к https://t.me/Verve_is_God")

    def get_email_link(self, msg_id: str, hwid, key, security):
        
        data = {
            "security": security,
            "hwid": hwid,
            "key": key,
            "login": self.login,
            "domain": self.domain,
            "id": msg_id
        }
        msg_id = requests.get(f"{api}/link",
                              json=data).json()
        if msg_id["status"] == 0:
            return msg_id["link"]
        elif msg_id["status"] == 1:
            exit("Ваш ключ забанен! Обратитесь к https://t.me/Verve_is_God, если считаете что это ошибка.")
        elif msg_id["status"] == 2:
            exit("Срок вашего ключа истёк! Обратитесь к https://t.me/Verve_is_God, если хотите продлить подписку.")
        elif msg_id["status"] == 3:
            exit("Данный ключ не существует! Обратитесь к https://t.me/Verve_is_God, если хотите купить ключ.")
        elif msg_id["status"] == 4:
            exit(f"Версия, которую вы используете ({version}) не действительна. Обратитесь к https://t.me/Verve_is_God за новой версией.")
        elif msg_id["status"] == 100:
            exit("Сервер обновляется. Приносим свои извинения! Попробуйте запустить скрипт через 5 минут, если ошибка снова повторится обратитесь к https://t.me/Verve_is_God")
        elif msg_id["status"] == 101:
            exit("Сервер изменил сигнатуру, обратитесь к https://t.me/Verve_is_God.")
        elif msg_id["status"] == 500:
            exit("Внутренняя ошибка сервера.")
        else:
            exit("Неизвестная ошибка, обратитесь к https://t.me/Verve_is_God")
