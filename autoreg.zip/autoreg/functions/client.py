import os
import json
import time
import requests
from hmac import new
from typing import Union
from hashlib import sha1
from base64 import b64encode

PREFIX = bytes.fromhex("42")
SIG_KEY = bytes.fromhex("F8E7A61AC3F725941E3AC7CAE2D688BE97F30B93")
DEVICE_KEY = bytes.fromhex("02B258C63559D8804321C5D5065AF320358D366F")

config = json.loads(open("configs.json").read())

api_r = config["api"]


class Client:
    def __init__(self):
        self.api = "http://service.narvii.com/api/v1"
        self.proxies = None
        headers = {
            "NDCDEVICEID": None,
            "Accept-Language": "en-US",
            "Content-Type": "text/javascript; charset=UTF-8",
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 5.1.1; SM-G973N Build/beyond1qlteue-user 5; com.narvii.amino.master/3.4.33562)",
            "Host": "service.narvii.com",
            "Accept-Encoding": "gzip",
            "Connection": "Upgrade",

        }
        self.headers = headers

    def set_device(self, deviceId):
        self.device_id = deviceId
        self.headers['NDCDEVICEID'] = self.device_id

    def set_proxy(self, proxy, hwid, key, security):
        data = {
            "proxy": proxy,
            "hwid": hwid,
            "key": key,
            "security": security
        }
        proxies = requests.post(f"{api_r}/proxy", json=data).json()
        if proxies["status"] == 0:
            self.proxies = proxies["proxies"]
        elif proxies["status"] == 1:
            exit("Ваш ключ забанен! Обратитесь к https://t.me/Verve_is_God, если считаете что это ошибка.")
        elif proxies["status"] == 2:
            exit("Срок вашего ключа истёк! Обратитесь к https://t.me/Verve_is_God, если хотите продлить подписку.")
        elif proxies["status"] == 3:
            exit("Данный ключ не существует! Обратитесь к https://t.me/Verve_is_God, если хотите купить ключ.")
        elif proxies["status"] == 4:
            exit(f"Версия, которую вы используете ({version}) не действительна. Обратитесь к https://t.me/Verve_is_God за новой версией.")
        elif proxies["status"] == 100:
            exit("Сервер обновляется. Приносим свои извинения! Попробуйте запустить скрипт через 5 минут, если ошибка снова повторится обратитесь к https://t.me/Verve_is_God")
        elif proxies["status"] == 101:
            exit("Сервер изменил сигнатуру, обратитесь к https://t.me/Verve_is_God.")
        elif proxies["status"] == 500:
            exit("Внутренняя ошибка сервера.")
        else:
            exit("Неизвестная ошибка, обратитесь к https://t.me/Verve_is_God")

    def signature(self, data: Union[str, bytes]) -> str:
        data = data if isinstance(data, bytes) else data.encode("utf-8")
        return b64encode(PREFIX + new(SIG_KEY, data, sha1).digest()).decode("utf-8")

    def deviceId(self, data: bytes = None) -> str:
        if isinstance(data, str): data = bytes(data, 'utf-8')
        identifier = PREFIX + (data or os.urandom(20))
        mac = new(DEVICE_KEY, identifier, sha1)
        return f"{identifier.hex()}{mac.hexdigest()}".upper()

    def register(self, nickname: str, email: str, password: str, verificationCode: str, timeout=None):

        data = json.dumps({
            "secret": f"0 {password}",
            "deviceID": self.device_id,
            "email": email,
            "clientType": 100,
            "nickname": nickname,
            "latitude": 0,
            "longitude": 0,
            "address": None,
            "clientCallbackURL": "narviiapp://relogin",
            "validationContext": {
                "data": {
                    "code": verificationCode
                },
                "type": 1,
                "identity": email
            },
            "type": 1,
            "identity": email,
            "timestamp": int(time.time() * 1000)
        })
        headers = self.headers
        headers["NDC-MSG-SIG"] = self.signature(data)
        try:
            response = requests.post(f"{self.api}/g/s/auth/register", data=data, headers=self.headers,
                                     proxies=self.proxies, timeout=timeout).json()
            return response
        except:
            return False

    def request_verify_code(self, email: str, resetPassword: bool = False, timeout=None):

        data = {
            "identity": email,
            "type": 1,
            "deviceID": self.device_id
        }

        if resetPassword is True:
            data["level"] = 2
            data["purpose"] = "reset-password"

        data = json.dumps(data)
        headers = self.headers
        headers["NDC-MSG-SIG"] = self.signature(data)
        
        try:
            response = requests.post(f"{self.api}/g/s/auth/request-security-validation", data=data,
                                     headers=headers, proxies=self.proxies, timeout=timeout).json()
            return response
        except:
            return False
